<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $nama_barang = $_POST['NAMA_BARANG'];  
    $harga_barang = $_POST['HARGA_BARANG'];  

    // Generate KD_BARANG  
    $kd_barang = "KDBG" . strtoupper(bin2hex(random_bytes(3))); // Menghasilkan KD_BARANG  
    $status = 1; // Status diisi 1  

    // SQL untuk menyimpan data ke tabel MASTER_BARANG  
    $sql = "INSERT INTO MASTER_BARANG (KD_BARANG, NAMA_BARANG, HARGA_BARANG, STATUS) VALUES (?, ?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("ssii", $kd_barang, $nama_barang, $harga_barang, $status); 
    if ($stmt->execute()) {  
        echo "Data berhasil disimpan.";  
    } else {  
        echo "Gagal menyimpan data: " . $stmt->error;  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>