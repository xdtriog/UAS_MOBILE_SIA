<?php  
include 'db_connect.php';  

// Ambil data dari tabel MASTER_BARANG  
$sql = "SELECT KD_BARANG, NAMA_BARANG, HARGA_BARANG, STATUS FROM MASTER_BARANG";  
$result = $koneksi->query($sql);  

$barangArray = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $barangArray[] = $row;  
    }  
    echo json_encode($barangArray);  
} else {  
    echo json_encode(array());  
}  

$koneksi->close();  
?>