<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $nik_karyawan = $_POST['NIK_KARYAWAN'];  
    $nik_customer = $_POST['NIK_CUSTOMER'];  
    $grand_total = $_POST['GRAND_TOTAL'];  
    $id_mmpn = $_POST['ID_MMPN'];  
    $detail_nota_jual = json_decode($_POST['DETAIL_NOTA_JUAL'], true);  
    $dp = isset($_POST['DP']) ? $_POST['DP'] : 0; // Menangani situasi tidak ada DP  
  
    // Generate NOMOR_NOTA  
    $nomor_nota = "NTJB" . strtoupper(bin2hex(random_bytes(5)));  

    // Insert into NOTA_JUAL  
    $sql_nota = "INSERT INTO NOTA_JUAL (NOMOR_NOTA, NIK_KARYAWAN, NIK_CUTOMER, ID_MMPN, TIMESTAMP, GRAND_TOTAL) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, ?)";  
    $stmt_nota = $koneksi->prepare($sql_nota);  
    $stmt_nota->bind_param("siisi", $nomor_nota, $nik_karyawan, $nik_customer, $id_mmpn, $grand_total);  

    if ($stmt_nota->execute()) {  
        // Insert each detail nota jual  
        foreach ($detail_nota_jual as $detail) {  
            $id_detail_nota_jual = "DNJB" . strtoupper(bin2hex(random_bytes(5)));  
            $kd_barang = $detail['KD_BARANG'];  
            $jumlah = $detail['JUMLAH'];  

            $sql_detail = "INSERT INTO DETAIL_NOTA_JUAL (ID_DETAIL_NOTA_JUAL, NOMOR_NOTA, KD_BARANG, JUMLAH) VALUES (?, ?, ?, ?)";  
            $stmt_detail = $koneksi->prepare($sql_detail);  
            $stmt_detail->bind_param("sssi", $id_detail_nota_jual, $nomor_nota, $kd_barang, $jumlah);  
            $stmt_detail->execute();  
        }  

        // Logika untuk memasukkan ke tabel JURNAL_UMUM  
        $month = date('m');  
        $year = date('y');  
        $uuid_jurnal = strtoupper(bin2hex(random_bytes(8)));  
        $id_jurnal_umum = "JU" . $month . $year . "-" . $uuid_jurnal;  
        
        if ($dp > 0) { // Memeriksa apakah DP lebih dari 0  
            $kd_debit = 1101; // DP  
            $kd_debit2 = 1201; // GRAND_TOTAL - DP  
            $kd_kredit = 4101; // KREDIT  
            $piutang = $grand_total - $dp; // Perhitungan piutang  

            // Insert into JURNAL_UMUM  
            $sql_jurnal = "INSERT INTO JURNAL_UMUM (ID_JURNAL_UMUM, KD_DEBIT, KD_DEBIT2, KD_KREDIT, TANGGAL, REF, DEBIT, KREDIT, DEBIT2) VALUES (?, ?, ?, ?, CURRENT_DATE, ?, ?, ?, ?)";  
            $stmt_jurnal = $koneksi->prepare($sql_jurnal);  
            $stmt_jurnal->bind_param("siiisiii", $id_jurnal_umum, $kd_debit, $kd_debit2, $kd_kredit, $nomor_nota, $dp, $grand_total, $piutang);  

            // Menyimpan data ke dalam tabel PIUTANG_CUSTOMER  
            $uuid_piutang = strtoupper(bin2hex(random_bytes(8)));   
            $id_piutang_customer = "PTCS" . $uuid_piutang; // Membuat ID_PIUTANG_CUSTOMER  
            $sql_piutang = "INSERT INTO PIUTANG_CUSTOMER (ID_PIUTANG_CUSTOMER, NOMOR_NOTA, JUMLAH_PIUTANG) VALUES (?, ?, ?)";  
            $stmt_piutang = $koneksi->prepare($sql_piutang);  
            $stmt_piutang->bind_param("ssi", $id_piutang_customer, $nomor_nota, $piutang);  
            $stmt_piutang->execute();  
        } else {  
            $kd_debit = 1101; // GRAND_TOTAL  
            $kd_kredit = 4101; // KREDIT  

            // Insert into JURNAL_UMUM  
            $sql_jurnal = "INSERT INTO JURNAL_UMUM (ID_JURNAL_UMUM, KD_DEBIT, KD_KREDIT, TANGGAL, REF, DEBIT, KREDIT) VALUES (?, ?, ?, CURRENT_DATE, ?, ?, ?)";  
            $stmt_jurnal = $koneksi->prepare($sql_jurnal);  
            $stmt_jurnal->bind_param("siisii", $id_jurnal_umum, $kd_debit, $kd_kredit, $nomor_nota, $grand_total);  
        }  

        $stmt_jurnal->execute();  
        echo "Nota berhasil disimpan!";  
    } else {  
        echo "Gagal menyimpan nota: " . $stmt_nota->error;  
    }  

    $stmt_nota->close();  
    $koneksi->close();  
}  
?>