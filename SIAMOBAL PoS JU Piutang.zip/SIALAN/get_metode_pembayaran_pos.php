<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $sql = "SELECT ID_MMPN, NAMA_MPPN FROM MASTER_METODE_PEMBAYARAN WHERE STATUS = 1";  
    $result = $koneksi->query($sql);  

    $payment_methods = array();  
    while ($row = $result->fetch_assoc()) {  
        $payment_methods[] = $row;  
    }  

    echo json_encode($payment_methods);  
}  

$koneksi->close();  
?>