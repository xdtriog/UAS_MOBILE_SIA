<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

// Mengatur header untuk JSON  
header('Content-Type: application/json');  

// Memeriksa apakah permintaan POST diterima  
if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    // Mengambil data dari permintaan POST  
    $id_membership = $_POST['id_membership'];  
    $nama_membership = $_POST['nama_membership'];  
    $harga_membership = $_POST['harga_membership'];  
    $potongan = $_POST['potongan'];  
    $status = $_POST['status']; // Ambil status  

    // Memperbarui data di database  
    $sql = "UPDATE MASTER_MEMBERSHIP SET   
                NAMA_MEMBERSHIP = ?,   
                HARGA_MEMBERSHIP = ?,   
                POTONGAN_ = ?,   
                STATUS = ?   
            WHERE ID_MASTER_MEMBERSHIP = ?"; // Menggunakan ID_MASTER_MEMBERSHIP  

    // Menyiapkan statement  
    if ($stmt = $koneksi->prepare($sql)) {  
        // Mengikat parameter  
        $stmt->bind_param("siiis", $nama_membership, $harga_membership, $potongan, $status, $id_membership);  

        // Menjalankan statement  
        if ($stmt->execute()) {  
            // Mengembalikan respons sukses  
            if ($stmt->affected_rows > 0) {  
                echo json_encode(array("status" => "success", "message" => "Membership updated successfully."));  
            } else {  
                echo json_encode(array("status" => "info", "message" => "No changes made. Membership may not exist or data is the same."));  
            }  
        } else {  
            // Mengembalikan respons gagal  
            echo json_encode(array("status" => "error", "message" => "Failed to update membership."));  
        }  

        // Menutup statement  
        $stmt->close();  
    } else {  
        // Mengembalikan respons gagal jika statement tidak dapat disiapkan  
        echo json_encode(array("status" => "error", "message" => "Failed to prepare statement."));  
    }  
} else {  
    // Mengembalikan respons jika bukan permintaan POST  
    echo json_encode(array("status" => "error", "message" => "Invalid request method."));  
}  

// Menutup koneksi  
$koneksi->close();  
?>