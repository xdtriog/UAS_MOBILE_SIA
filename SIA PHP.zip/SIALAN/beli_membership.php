<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $id_master_membership = $_POST['ID_MASTER_MEMBERSHIP'];  
    $nik_customer = $_POST['NIK_CUTOMER'];  

    // Ambil data dari tabel MASTER_MEMBERSHIP  
    $sqlMembership = "SELECT NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_ FROM MASTER_MEMBERSHIP WHERE ID_MASTER_MEMBERSHIP = ?";  
    $stmtMembership = $koneksi->prepare($sqlMembership);  
    $stmtMembership->bind_param("s", $id_master_membership);  
    $stmtMembership->execute();  
    $resultMembership = $stmtMembership->get_result();  

    if ($resultMembership->num_rows > 0) {  
        $membershipData = $resultMembership->fetch_assoc();  
        $nama_membership = $membershipData['NAMA_MEMBERSHIP'];  
        $harga_membership = $membershipData['HARGA_MEMBERSHIP'];  
        $potongan = $membershipData['POTONGAN_'];  
    } else {  
        echo "ID_MASTER_MEMBERSHIP tidak ditemukan.";  
        exit;  
    }  

    // Generate timestamp habis (sekarang + 1 bulan)  
    $timestamp_habis = date('Y-m-d H:i:s', strtotime('+1 month'));  

    // Generate ID_TRANS_MEMBERSHIP dengan format TMBP + UUID 16 karakter  
    $uuid = strtoupper(bin2hex(random_bytes(8))); // Menghasilkan 16 karakter UUID  
    $id_trans_membership = "TMBP" . $uuid; // Contoh: TMBPABCDEF123456  

    // SQL untuk menyimpan data  
    $sql = "INSERT INTO TRANS_MEMBERSHIP (ID_TRANS_MEMBERSHIP, ID_MASTER_MEMBERSHIP, NIK_CUTOMER, NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_, TIMESTAMP_HABIS) VALUES (?, ?, ?, ?, ?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  

    $stmt->bind_param("ssisiis", $id_trans_membership, $id_master_membership, $nik_customer, $nama_membership, $harga_membership, $potongan, $timestamp_habis);  

    if ($stmt->execute()) {  
        echo "Transaksi berhasil disimpan";  
    } else {  
        echo "Gagal menyimpan transaksi: " . $stmt->error;  
    }  

    $stmt->close();  
    $stmtMembership->close();  
    $koneksi->close();  
}  
?>