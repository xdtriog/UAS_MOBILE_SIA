<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $sql = "SELECT NIK_CUTOMER, NAMA_CUSTOMER FROM CUSTOMER";  
    $result = $koneksi->query($sql);  

    $customers = array();  
    while ($row = $result->fetch_assoc()) {  
        $customers[] = $row;  
    }  

    echo json_encode($customers);  
}  

$koneksi->close();  
?>