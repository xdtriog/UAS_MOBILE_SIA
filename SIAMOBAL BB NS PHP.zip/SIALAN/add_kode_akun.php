<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $kode_akun = $_POST['KODE_AKUN'];  
    $nama_akun = $_POST['NAMA_AKUN'];  

    // SQL untuk menyimpan data ke tabel KODE_AKUN  
    $sql = "INSERT INTO KODE_AKUN (KODE_AKUN, NAMA_AKUN) VALUES (?, ?)";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("is", $kode_akun, $nama_akun); // "is" untuk integer dan string  

    if ($stmt->execute()) {  
        echo "Data berhasil disimpan.";  
    } else {  
        echo "Gagal menyimpan data: " . $stmt->error;  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>