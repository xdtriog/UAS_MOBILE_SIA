<?php  
include 'db_connect.php'; // Pastikan ini mengarah pada file yang benar  

// Query untuk mengambil data dari PIUTANG_CUSTOMER dengan perhitungan jumlah cicilan  
$sql = "SELECT   
            pc.ID_PIUTANG_CUSTOMER,   
            pc.NOMOR_NOTA,   
            c.NAMA_CUSTOMER,   
            (pc.JUMLAH_PIUTANG - IFNULL(SUM(tp.JUMLAH_BAYAR), 0)) AS JUMLAH_PIUTANG   
        FROM   
            PIUTANG_CUSTOMER pc   
        JOIN   
            NOTA_JUAL nj ON pc.NOMOR_NOTA = nj.NOMOR_NOTA   
        JOIN   
            CUSTOMER c ON nj.NIK_CUTOMER = c.NIK_CUTOMER   
        LEFT JOIN   
            TRANS_CICILAN_PIUTANG tp ON pc.ID_PIUTANG_CUSTOMER = tp.ID_PIUTANG_CUSTOMER   
        GROUP BY   
            pc.ID_PIUTANG_CUSTOMER, pc.NOMOR_NOTA, c.NAMA_CUSTOMER, pc.JUMLAH_PIUTANG   
        ORDER BY   
            JUMLAH_PIUTANG DESC"; // Mengurutkan dari yang terbesar  

$result = $koneksi->query($sql);   

$response = array();  

if ($result->num_rows > 0) {  
    // output data of each row  
    while ($row = $result->fetch_assoc()) {  
        $response[] = $row;  
    }  
}   

// Mengembalikan hasil sebagai JSON  
echo json_encode($response);  

$koneksi->close();  
?>