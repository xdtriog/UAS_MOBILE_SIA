<?php  
header('Content-Type: application/json');  

// Masukkan file koneksi  
include 'db_connect.php';  

// Ambil data dari permintaan POST  
$nik = $_POST['NIK_KARYAWAN'];  
$nama = $_POST['NAMA_KARYAWAN'];  
$email = $_POST['EMAIL'];  
$password = $_POST['PASSWORD'];  

// Query untuk memperbarui data karyawan  
$sql = "UPDATE KARYAWAN SET NAMA_KARYAWAN=?, EMAIL=?, PASSWORD=? WHERE NIK_KARYAWAN=?";  
$stmt = $koneksi->prepare($sql);  
$stmt->bind_param("sssi", $nama, $email, $password, $nik);  

if ($stmt->execute()) {  
    echo json_encode(array("status" => "success", "message" => "Karyawan berhasil diperbarui"));  
} else {  
    echo json_encode(array("status" => "error", "message" => "Gagal memperbarui karyawan: " . $stmt->error));  
}  

// Tutup koneksi  
$stmt->close();  
$koneksi->close();  
?>