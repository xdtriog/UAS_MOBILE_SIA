<?php  
header('Content-Type: application/json');  

// Masukkan file koneksi  
include 'db_connect.php';  

// Query untuk mengambil data karyawan  
$sql = "SELECT NIK_KARYAWAN, NAMA_KARYAWAN, EMAIL, PASSWORD FROM KARYAWAN";  
$result = $koneksi->query($sql);  

$karyawan = array();  

if ($result->num_rows > 0) {  
    // Mengambil data tiap baris  
    while($row = $result->fetch_assoc()) {  
        $karyawan[] = $row;  
    }  
}  

// Tutup koneksi  
$koneksi->close();  

// Mengembalikan data dalam format JSON  
echo json_encode($karyawan);  
?>