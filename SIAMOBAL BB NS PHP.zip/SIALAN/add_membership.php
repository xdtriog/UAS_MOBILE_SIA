<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    // Ambil data dari POST  
    $nama_membership = $_POST['nama_membership'];  
    $harga_membership = $_POST['harga_membership'];  
    $potongan = $_POST['potongan'];  
    $nik_karyawan = $_POST['nik_karyawan']; // Ambil NIK_KARYAWAN dari request  

    // Generate ID_MASTER_MEMBERSHIP  
    $uuid = strtoupper(bin2hex(random_bytes(3))); // Menghasilkan 6 karakter UUID  
    $id_master_membership = "MMBP" . $uuid; // Contoh: MMBPABCDEF  

    // Timestamp untuk LAST_UPDATED  
    $last_updated = date("Y-m-d H:i:s");  

    // SQL untuk menyimpan data  
    $sql = "INSERT INTO MASTER_MEMBERSHIP (ID_MASTER_MEMBERSHIP, NIK_KARYAWAN, NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_, STATUS, LAST_UPDATED) VALUES (?, ?, ?, ?, ?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  
    $status = 1; // Status aktif  

    $stmt->bind_param("sisssis", $id_master_membership, $nik_karyawan, $nama_membership, $harga_membership, $potongan, $status, $last_updated);  

    if ($stmt->execute()) {  
        echo "Membership berhasil ditambahkan";  
    } else {  
        echo "Gagal menambahkan membership: " . $stmt->error;  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>