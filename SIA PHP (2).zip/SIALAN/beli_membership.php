<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $id_master_membership = $_POST['ID_MASTER_MEMBERSHIP'];  
    $nik_customer = $_POST['NIK_CUTOMER'];  

    // Ambil data dari tabel MASTER_MEMBERSHIP  
    $sqlMembership = "SELECT NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_ FROM MASTER_MEMBERSHIP WHERE ID_MASTER_MEMBERSHIP = ?";  
    $stmtMembership = $koneksi->prepare($sqlMembership);  
    $stmtMembership->bind_param("s", $id_master_membership);  
    $stmtMembership->execute();  
    $resultMembership = $stmtMembership->get_result();  

    if ($resultMembership->num_rows > 0) {  
        $membershipData = $resultMembership->fetch_assoc();  
        $nama_membership = $membershipData['NAMA_MEMBERSHIP'];  
        $harga_membership = $membershipData['HARGA_MEMBERSHIP'];  
        $potongan = $membershipData['POTONGAN_'];  
    } else {  
        echo json_encode(array("status" => "error", "message" => "ID_MASTER_MEMBERSHIP tidak ditemukan."));  
        exit;  
    }  

    // Generate ID_TRANS_MEMBERSHIP dengan format TMBP + UUID 16 karakter  
    $uuid = strtoupper(bin2hex(random_bytes(8))); // Menghasilkan 16 karakter UUID  
    $id_trans_membership = "TMBP" . $uuid; // Contoh: TMBPABCDEF123456  

    // SQL untuk menyimpan data ke TRANS_MEMBERSHIP  
    $sql = "INSERT INTO TRANS_MEMBERSHIP (ID_TRANS_MEMBERSHIP, ID_MASTER_MEMBERSHIP, NIK_CUTOMER, NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_, TIMESTAMP_HABIS) VALUES (?, ?, ?, ?, ?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  

    $timestamp_habis = date('Y-m-d H:i:s', strtotime('+1 month'));  
    $stmt->bind_param("ssisiis", $id_trans_membership, $id_master_membership, $nik_customer, $nama_membership, $harga_membership, $potongan, $timestamp_habis);  

    if ($stmt->execute()) {  
        // Setelah berhasil menyimpan transaksi, simpan ke JURNAL_UMUM  
        $month = date('m'); // Bulan saat ini  
        $year = date('y'); // Tahun saat ini  
        $uuid_jurnal = strtoupper(bin2hex(random_bytes(8))); // UUID untuk ID_JURNAL_UMUM  
        $id_jurnal_umum = "JU" . $month . $year . "-" . $uuid_jurnal; // Format JU1224 + UUID  

        $kd_debit = 1101;  
        $kd_kredit = 4201;  
        $ref = $id_trans_membership;  
        $debit = $harga_membership;  
        $kredit = $harga_membership;  

        // SQL untuk menyimpan data ke JURNAL_UMUM  
        $sqlJurnal = "INSERT INTO JURNAL_UMUM (ID_JURNAL_UMUM, KD_DEBIT, KD_KREDIT, TANGGAL, REF, DEBIT, KREDIT) VALUES (?, ?, ?, CURDATE(), ?, ?, ?)";  
        $stmtJurnal = $koneksi->prepare($sqlJurnal);  
        $stmtJurnal->bind_param("siisii", $id_jurnal_umum, $kd_debit, $kd_kredit, $ref, $debit, $kredit);  

        if ($stmtJurnal->execute()) {  
            // Mengembalikan ID_JURNAL_UMUM sebagai respons  
            echo json_encode(array("status" => "success", "id_jurnal_umum" => $id_jurnal_umum));  
        } else {  
            echo json_encode(array("status" => "error", "message" => "Gagal menyimpan jurnal umum: " . $stmtJurnal->error));  
        }  
    } else {  
        echo json_encode(array("status" => "error", "message" => "Gagal menyimpan transaksi: " . $stmt->error));  
    }  

    $stmt->close();  
    $stmtMembership->close();  
    $koneksi->close();  
}  
?>