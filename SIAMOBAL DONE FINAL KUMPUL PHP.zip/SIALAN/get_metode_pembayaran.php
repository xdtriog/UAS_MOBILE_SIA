<?php  
include 'db_connect.php';  

// Ambil data dari tabel MASTER_METODE_PEMBAYARAN  
$sql = "SELECT ID_MMPN, NAMA_MPPN, STATUS FROM MASTER_METODE_PEMBAYARAN";  
$result = $koneksi->query($sql);  

$metodePembayaranArray = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $metodePembayaranArray[] = $row;  
    }  
    echo json_encode($metodePembayaranArray);  
} else {  
    echo json_encode(array());  
}  

$koneksi->close();  
?>