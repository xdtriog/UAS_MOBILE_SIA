<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $nama_mppn = $_POST['NAMA_MPPN'];  

    // Generate ID_MMPN  
    $id_mmpn = "MMPN" . strtoupper(bin2hex(random_bytes(3))); // Menghasilkan ID_MMPN  
    $status = 1; // Status diisi 1  

    // SQL untuk menyimpan data ke tabel MASTER_METODE_PEMBAYARAN  
    $sql = "INSERT INTO MASTER_METODE_PEMBAYARAN (ID_MMPN, NAMA_MPPN, STATUS) VALUES (?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("ssi", $id_mmpn, $nama_mppn, $status); // "ssi" untuk string, string, integer  

    if ($stmt->execute()) {  
        echo "Data berhasil disimpan.";  
    } else {  
        echo "Gagal menyimpan data: " . $stmt->error;  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>