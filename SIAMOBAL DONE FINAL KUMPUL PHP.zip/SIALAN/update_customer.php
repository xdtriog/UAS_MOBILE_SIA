<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $nik_customer = $_POST['NIK_CUTOMER'];  
    $nama_customer = $_POST['NAMA_CUSTOMER'];  
    $email = $_POST['EMAIL'];  

    $sql = "UPDATE CUSTOMER SET NAMA_CUSTOMER = ?, EMAIL = ? WHERE NIK_CUTOMER = ?";  

    if ($stmt = $koneksi->prepare($sql)) {  
        $stmt->bind_param("ssi", $nama_customer, $email, $nik_customer);  
        $stmt->execute();  

        if ($stmt->affected_rows > 0) {  
            echo json_encode(["success" => true]);  
        } else {  
            echo json_encode(["success" => false, "message" => "Data tidak berubah."]);  
        }  

        $stmt->close();  
    } else {  
        echo json_encode(["success" => false, "message" => "Error preparing statement."]);  
    }  
}  
$koneksi->close();  
?>