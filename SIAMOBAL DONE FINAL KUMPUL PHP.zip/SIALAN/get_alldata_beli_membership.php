<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

header('Content-Type: application/json');  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    // Ambil data customer  
    $sqlCustomers = "SELECT NIK_CUTOMER, NAMA_CUSTOMER FROM CUSTOMER";  
    $resultCustomers = $koneksi->query($sqlCustomers);  

    $customers = array();  
    if ($resultCustomers->num_rows > 0) {  
        while ($row = $resultCustomers->fetch_assoc()) {  
            $customers[] = $row;  
        }  
    }  

    // Ambil data membership  
    $sqlMemberships = "SELECT ID_MASTER_MEMBERSHIP, NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_ FROM MASTER_MEMBERSHIP WHERE STATUS = 1";  
    $resultMemberships = $koneksi->query($sqlMemberships);  

    $memberships = array();  
    if ($resultMemberships->num_rows > 0) {  
        while ($row = $resultMemberships->fetch_assoc()) {  
            $memberships[] = $row;  
        }  
    }  

    // Gabungkan data customer dan membership  
    $data = array(  
        'customers' => $customers,  
        'memberships' => $memberships  
    );  

    echo json_encode($data);  
}  

$koneksi->close();  
?>