<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $nik_customer = $_POST['NIK_CUTOMER'];  

    $sql = "SELECT POTONGAN_ FROM TRANS_MEMBERSHIP WHERE NIK_CUTOMER = ? AND TIMESTAMP_HABIS > NOW() LIMIT 1";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("s", $nik_customer);  
    $stmt->execute();  
    $result = $stmt->get_result();  

    if ($result->num_rows > 0) {  
        $row = $result->fetch_assoc();  
        echo json_encode($row);  
    } else {  
        echo json_encode(["POTONGAN_" => 0]); // Jika tidak ada potongan, kirim 0  
    }  

    $stmt->close();  
}  
$koneksi->close();  
?>