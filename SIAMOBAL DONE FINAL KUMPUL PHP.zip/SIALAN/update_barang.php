<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $kd_barang = $_POST['kd_barang'];  
    $nama_barang = $_POST['nama_barang'];  
    $harga_barang = $_POST['harga_barang'];  
    $status = $_POST['status'];  

    // SQL untuk memperbarui data barang  
    $sql = "UPDATE MASTER_BARANG SET NAMA_BARANG = ?, HARGA_BARANG = ?, STATUS = ? WHERE KD_BARANG = ?";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("siis", $nama_barang, $harga_barang, $status, $kd_barang);  

    if ($stmt->execute()) {  
        echo json_encode(array("status" => "success"));  
    } else {  
        echo json_encode(array("status" => "error", "message" => "Gagal memperbarui data: " . $stmt->error));  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>