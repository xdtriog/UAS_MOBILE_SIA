<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $email = $_POST['email'];  
    $password = $_POST['password'];  

    // Mencari pengguna berdasarkan email  
    $sql = "SELECT * FROM KARYAWAN WHERE EMAIL = ?";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("s", $email);  
    $stmt->execute();  
    $result = $stmt->get_result();  

    if ($result->num_rows > 0) {  
        $user = $result->fetch_assoc();  
        
        // Verifikasi password tanpa hashing  
        if ($password === $user['PASSWORD']) {  
            // Login berhasil  
            echo json_encode(array("success" => true, "message" => "Login berhasil", "user" => $user));  
        } else {  
            // Password salah  
            echo json_encode(array("success" => false, "message" => "Password salah"));  
        }  
    } else {  
        // Email tidak ditemukan  
        echo json_encode(array("success" => false, "message" => "Email tidak ditemukan"));  
    }  

    $stmt->close();  
}  
$conn->close();  
?>