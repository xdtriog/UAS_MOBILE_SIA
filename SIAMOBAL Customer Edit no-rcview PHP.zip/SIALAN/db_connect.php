<?php


$servername = "localhost";
$database = "keve8286_SIALAN";
$username = "keve8286_SIALAN";
$password = "Sialan666";

// Create connection
$koneksi = new mysqli($servername, $username, $password, $database);

// Check connection 

if ($koneksi->connect_error) {
    die("Connection failed: " . $koneksi->connect_error);
}
// else { echo "Connected successfully";
// }
?>