<?php  
include 'db_connect.php'; // Include your database connection file  

$selectedDate = $_GET['tanggal']; // Expecting format MM - YYYY  
list($month, $year) = explode(" - ", $selectedDate);  

// Mendapatkan tanggal pertama dan terakhir dalam bulan yang dipilih  
$startDate = "$year-$month-01";  
$endDate = date('Y-m-t', strtotime($startDate)); // Mendapatkan hari terakhir bulan tersebut  

// Query untuk mendapatkan data  
$sql = "SELECT ka.KODE_AKUN, ka.NAMA_AKUN,  
        COALESCE(SUM(CASE   
            WHEN ju.TANGGAL BETWEEN '$startDate' AND '$endDate' THEN   
            CASE   
                WHEN ju.KD_DEBIT = ka.KODE_AKUN THEN ju.DEBIT   
                WHEN ju.KD_DEBIT2 = ka.KODE_AKUN THEN ju.DEBIT2   
            END   
        END), 0) AS DEBIT,  
        COALESCE(SUM(CASE   
            WHEN ju.TANGGAL BETWEEN '$startDate' AND '$endDate' THEN   
            CASE   
                WHEN ju.KD_KREDIT = ka.KODE_AKUN THEN ju.KREDIT   
                WHEN ju.KD_KREDIT2 = ka.KODE_AKUN THEN ju.KREDIT2   
            END   
        END), 0) AS KREDIT  
    FROM KODE_AKUN ka  
    LEFT JOIN JURNAL_UMUM ju ON ka.KODE_AKUN IN (ju.KD_DEBIT, ju.KD_DEBIT2, ju.KD_KREDIT, ju.KD_KREDIT2)  
    GROUP BY ka.KODE_AKUN, ka.NAMA_AKUN;";  

$result = $koneksi->query($sql);  
$data = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $data[] = $row;  
    }  
    echo json_encode($data);  
} else {  
    echo json_encode([]);  
}  

$koneksi->close();  
?>