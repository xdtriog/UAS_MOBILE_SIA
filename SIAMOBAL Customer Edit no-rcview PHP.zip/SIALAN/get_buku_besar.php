<?php  
include 'db_connect.php';  

if (isset($_GET['filter']) && isset($_GET['kode_akun'])) {  
    $filter = $_GET['filter']; // Format: "01 - 2025"  
    $kode_akun = $_GET['kode_akun'];  

    list($month, $year) = explode(" - ", $filter);  

    // Query untuk mengambil data dari JURNAL_UMUM dan KODE_AKUN  
    $sql = "  
    SELECT   
        ju.TANGGAL,  
        ka.NAMA_AKUN AS KETERANGAN,  
        ju.REF,  
        CASE WHEN ju.KD_DEBIT = ka.KODE_AKUN THEN ju.DEBIT ELSE '0' END AS DEBIT,  
        CASE WHEN ju.KD_DEBIT2 = ka.KODE_AKUN THEN ju.DEBIT2 ELSE '0' END AS DEBIT2,  
        CASE WHEN ju.KD_KREDIT = ka.KODE_AKUN THEN ju.KREDIT ELSE '0' END AS KREDIT,  
        CASE WHEN ju.KD_KREDIT2 = ka.KODE_AKUN THEN ju.KREDIT2 ELSE '0' END AS KREDIT2  
    FROM   
        JURNAL_UMUM ju  
    JOIN   
        KODE_AKUN ka ON ju.KD_DEBIT = ka.KODE_AKUN OR ju.KD_DEBIT2 = ka.KODE_AKUN OR ju.KD_KREDIT = ka.KODE_AKUN OR ju.KD_KREDIT2 = ka.KODE_AKUN  
    WHERE   
        MONTH(ju.TANGGAL) = ? AND YEAR(ju.TANGGAL) = ? AND ka.KODE_AKUN = ?  
    ORDER BY   
        ju.REF, ju.TANGGAL  
    ";  

    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("iii", $month, $year, $kode_akun);  
    $stmt->execute();  
    $result = $stmt->get_result();  

    $data = array();  
    while ($row = $result->fetch_assoc()) {  
        $data[] = $row;  
    }  
    echo json_encode($data);  
}  

$stmt->close();  
$koneksi->close();  
?>