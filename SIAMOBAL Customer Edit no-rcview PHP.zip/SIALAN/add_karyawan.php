<?php  
header('Content-Type: application/json');  

// Masukkan file koneksi  
include 'db_connect.php';  

// Ambil data dari permintaan POST  
$nik = $_POST['NIK_KARYAWAN'];  
$nama = $_POST['NAMA_KARYAWAN'];  
$email = $_POST['EMAIL'];  
$password = $_POST['PASSWORD'];  

// Query untuk menyimpan data ke tabel KARYAWAN  
$sql = "INSERT INTO KARYAWAN (NIK_KARYAWAN, NAMA_KARYAWAN, EMAIL, PASSWORD) VALUES (?, ?, ?, ?)";  
$stmt = $koneksi->prepare($sql);  
$stmt->bind_param("isss", $nik, $nama, $email, $password);  

if ($stmt->execute()) {  
    echo json_encode(array("status" => "success", "message" => "Karyawan berhasil ditambahkan"));  
} else {  
    echo json_encode(array("status" => "error", "message" => "Gagal menambahkan karyawan: " . $stmt->error));  
}  

// Tutup koneksi  
$stmt->close();  
$koneksi->close();  
?>