<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $sql = "SELECT c.NIK_CUTOMER, c.NAMA_CUSTOMER, c.EMAIL,  -- Menambahkan EMAIL  
                   COALESCE(tm.NAMA_MEMBERSHIP, '-') AS NAMA_MEMBERSHIP,   
                   COALESCE(tm.TIMESTAMP_HABIS, '-') AS TIMESTAMP_HABIS   
            FROM CUSTOMER c   
            LEFT JOIN TRANS_MEMBERSHIP tm ON c.NIK_CUTOMER = tm.NIK_CUTOMER";  

    $result = $koneksi->query($sql);  

    $customers = array();  

    if ($result->num_rows > 0) {  
        while ($row = $result->fetch_assoc()) {  
            $customers[] = $row;  
        }  
    }  

    echo json_encode($customers);  
}  
?>