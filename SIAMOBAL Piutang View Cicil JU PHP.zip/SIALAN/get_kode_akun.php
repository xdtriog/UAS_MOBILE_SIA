<?php  
include 'db_connect.php';  

// Ambil data dari tabel KODE_AKUN  
$sql = "SELECT KODE_AKUN, NAMA_AKUN FROM KODE_AKUN";  
$result = $koneksi->query($sql);  

$kodeAkunArray = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $kodeAkunArray[] = $row;  
    }  
    echo json_encode($kodeAkunArray);  
} else {  
    echo json_encode(array());  
}  

$koneksi->close();  
?>