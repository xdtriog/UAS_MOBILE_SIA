<?php  
include 'db_connect.php';  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    $kode_akun = $_POST['KODE_AKUN'];  

    // SQL untuk memeriksa apakah KODE_AKUN sudah ada  
    $sql = "SELECT * FROM KODE_AKUN WHERE KODE_AKUN = ?";  
    $stmt = $koneksi->prepare($sql);  
    $stmt->bind_param("i", $kode_akun); // "i" untuk integer  

    $stmt->execute();  
    $result = $stmt->get_result();  

    if ($result->num_rows > 0) {  
        echo json_encode(array("exists" => true));  
    } else {  
        echo json_encode(array("exists" => false));  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>