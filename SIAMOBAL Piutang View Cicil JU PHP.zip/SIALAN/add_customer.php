<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    // Ambil data dari POST  
    $nik_customer = $_POST['nik_customer'];  
    $nama_customer = $_POST['nama_customer'];  
    $email = $_POST['email'];  

    // SQL untuk menyimpan data  
    $sql = "INSERT INTO CUSTOMER (NIK_CUTOMER, NAMA_CUSTOMER, EMAIL) VALUES (?, ?, ?)";  
    $stmt = $koneksi->prepare($sql);  

    // Mengikat parameter  
    $stmt->bind_param("iss", $nik_customer, $nama_customer, $email);  

    if ($stmt->execute()) {  
        echo "Customer berhasil ditambahkan";  
    } else {  
        echo "Gagal menambahkan customer: " . $stmt->error;  
    }  

    $stmt->close();  
    $koneksi->close();  
}  
?>