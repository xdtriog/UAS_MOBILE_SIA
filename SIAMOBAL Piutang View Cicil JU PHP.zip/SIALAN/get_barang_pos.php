<?php  
include 'db_connect.php';  

// Ambil data dari tabel MASTER_BARANG dengan status == 1  
$sql = "SELECT KD_BARANG, NAMA_BARANG, HARGA_BARANG FROM MASTER_BARANG WHERE STATUS = 1";  
$result = $koneksi->query($sql);  

$barangArray = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $barangArray[] = $row;  
    }  
    echo json_encode($barangArray);  
} else {  
    echo json_encode(array());  
}  

$koneksi->close();  
?>