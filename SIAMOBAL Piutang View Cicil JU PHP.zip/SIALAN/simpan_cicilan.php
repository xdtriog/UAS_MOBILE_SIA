<?php  
include 'db_connect.php'; // Pastikan ini mengarah pada file yang benar  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {  
    // Ambil parameter dari request  
    $idPiutangCustomer = $_POST['ID_PIUTANG_CUSTOMER'];  
    $jumlahBayar = $_POST['JUMLAH_BAYAR'];  
    $waktuCicil = date('Y-m-d H:i:s'); // Dapatkan waktu saat ini  

    // Generate ID_CICILAN_PIUTANG  
    $uuid = strtoupper(bin2hex(random_bytes(8))); // Menghasilkan 16 karakter UUID  
    $idCicilan = "CCPT" . $uuid; // Contoh: CCPTABCDEF123456  

    // Masukkan data ke dalam tabel TRANS_CICILAN_PIUTANG  
    $sql = "INSERT INTO TRANS_CICILAN_PIUTANG (ID_CICILAN_PIUTANG, ID_PIUTANG_CUSTOMER, JUMLAH_BAYAR, WAKTU_CICIL)   
            VALUES ('$idCicilan', '$idPiutangCustomer', '$jumlahBayar', '$waktuCicil')";  

    if ($koneksi->query($sql) === TRUE) {  
        // Setelah berhasil menyimpan transaksi, simpan ke JURNAL_UMUM  
        $month = date('m'); // Bulan saat ini  
        $year = date('y'); // Tahun saat ini  
        $uuid_jurnal = strtoupper(bin2hex(random_bytes(8))); // UUID untuk ID_JURNAL_UMUM  
        $id_jurnal_umum = "JU" . $month . $year . "-" . $uuid_jurnal; // Format JU1224 + UUID  

        // Siapkan query untuk JURNAL_UMUM  
        $kdDebit = 1101;  
        $kdKredit = 1201;  
        $ref = $idCicilan;  
        $debit = $jumlahBayar;  
        $kredit = $jumlahBayar;  

        $sql_jurnal = "INSERT INTO JURNAL_UMUM (ID_JURNAL_UMUM, KD_DEBIT, KD_KREDIT, TANGGAL, REF, DEBIT, KREDIT)   
                       VALUES ('$id_jurnal_umum', $kdDebit, $kdKredit, CURDATE(), '$ref', $debit, $kredit)";  

        // Eksekusi query JURNAL_UMUM  
        if ($koneksi->query($sql_jurnal) === TRUE) {  
            echo json_encode(array("message" => "Cicilan dan Jurnal berhasil disimpan"));  
        } else {  
            echo json_encode(array("message" => "Error saat menyimpan Jurnal: " . $koneksi->error));  
        }  
    } else {  
        echo json_encode(array("message" => "Error saat menyimpan cicilan: " . $koneksi->error));  
    }  

    $koneksi->close();  
} else {  
    echo json_encode(array("message" => "Invalid request"));  
}  
?>