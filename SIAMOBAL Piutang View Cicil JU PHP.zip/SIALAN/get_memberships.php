<?php  
include 'db_connect.php'; // Pastikan ini mengarah ke file koneksi database Anda  

header('Content-Type: application/json');  

$sql = "SELECT ID_MASTER_MEMBERSHIP, NAMA_MEMBERSHIP, HARGA_MEMBERSHIP, POTONGAN_, STATUS FROM MASTER_MEMBERSHIP";  
$result = $koneksi->query($sql);  

$memberships = array();  

if ($result->num_rows > 0) {  
    while ($row = $result->fetch_assoc()) {  
        $memberships[] = array(  
            'id' => $row['ID_MASTER_MEMBERSHIP'], // Tambahkan ID  
            'nama' => $row['NAMA_MEMBERSHIP'],  
            'harga' => $row['HARGA_MEMBERSHIP'],  
            'potongan' => $row['POTONGAN_'],  
            'status' => $row['STATUS']  
        );  
    }  
}  

echo json_encode($memberships);  
$koneksi->close();  
?>